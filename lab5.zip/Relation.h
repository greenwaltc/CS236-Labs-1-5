//
// Created by camer on 7/16/2020.
//

#ifndef PROJECT1_RELATION_H
#define PROJECT1_RELATION_H

#include <vector>
#include <string>
#include <set>
#include <iostream>
#include <algorithm>
#include <sstream>
#include "Scheme.h"
#include "Tuple.h"
using namespace std;

class Relation{
private:
    string name;
    Scheme scheme;
    set<Tuple> collection;
    vector<int> variableIndexes;
    bool canJoin;

public:
    Relation(){}
    Relation(string name, Scheme scheme);
    void addTuple(Tuple tuple);
    string toString();
    string getName();
    Scheme getScheme();
    int getCollectionSize();
    set<Tuple> getCollection();
    vector<int> getVariableIndexes();

    /*----------------*/
    Relation select(int index, string value, string name, Scheme scheme); //Index is the attribute or column name, value is in the tuples
    Relation select(int index1, int index2, string name, Scheme scheme);
    Relation project(vector<int> indexes, string name, vector<string> attributes);
    Relation projectRule(string name, vector<string> headVariables);
    void rename(vector<string> names, vector<int> indexes);
    void rename(vector<string> names);

    /*----------------*/
    Relation join(Relation r1, Relation r2);
    Tuple joinTuple(Tuple t1, Tuple t2, vector<pair<unsigned int, unsigned int>> indexes);
    bool isJoinable(Tuple t1, Tuple t2, vector<pair<unsigned int, unsigned int>> indexes);
    Scheme combineSchemes(Scheme s1, Scheme s2);
    vector<pair<unsigned int, unsigned int>> align(Scheme s1, Scheme s2);
    void unionize(Relation ruleRelation);
};

#endif //PROJECT1_RELATION_H
