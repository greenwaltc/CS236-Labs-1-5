//
// Created by camer on 6/25/2020.
//
#include "Token.h"

void Token::setType(tokenType type) { this->type = type; }
void Token::setValue(string value)  { this->value = value; }
void Token::setLineNum(int lineNum) { this->line = lineNum; }

Token::tokenType Token::getType(){ return type; }
string Token::getValue() { return value; }
int Token::getLine() { return line; }

string Token::toString(){
    string str;
    switch (type) {
        case Token::COMMA:       str = "COMMA";      break;
        case Token::PERIOD:      str = "PERIOD";     break;
        case Token::Q_MARK:      str = "Q_MARK";     break;
        case Token::LEFT_PAREN:  str = "LEFT_PAREN"; break;
        case Token::RIGHT_PAREN: str = "RIGHT_PAREN";break;
        case Token::COLON:       str = "COLON";      break;
        case Token::COLON_DASH:  str = "COLON_DASH"; break;
        case Token::MULTIPLY:    str = "MULTIPLY";   break;
        case Token::ADD:         str = "ADD";        break;
        case Token::SCHEMES:     str = "SCHEMES";    break;
        case Token::FACTS:       str = "FACTS";      break;
        case Token::RULES:       str = "RULES";      break;
        case Token::QUERIES:     str = "QUERIES";    break;
        case Token::ID:          str = "ID";         break;
        case Token::STRING:      str = "STRING";     break;
        case Token::COMMENT:     str = "COMMENT";    break;
        case Token::UNDEFINED:   str = "UNDEFINED";  break;
        case Token::eof:         str = "EOF";        break;
    }

    string ret = '(' + str + ",\"" + value + "\"," + to_string(line) + ')';
    return ret;
}