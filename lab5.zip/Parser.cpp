//
// Created by camer on 7/2/2020.
//

#include "Parser.h"

bool Parser::success() { return successfulParse; }

void Parser::match(Token::tokenType type){
    //Check if next token has the provided type
    if (currentToken.getType() == type){
        //Advance to the next token
        //This means that the func matched appropriately and shouldn't throw errors
        if ( type != Token::eof ) index++;
        if ( unsigned(index) >= toParse.size() ){ //Safeguard //Cast to unsigned to avoid warnings on linux machines
            throw std::out_of_range("Invalid index value -- too large");
        }
        currentToken = toParse[index];
    }
    else {
        throw currentToken;
    }
}

DatalogProgram Parser::parse() {
    DatalogProgram program;
    try {
        currentToken = toParse[index];
        program = parseDatalogProgram();
        successfulParse = true;
        //cout << "Success!" << endl; //Try block succeeded
        return program;
    } catch (Token error){
        cout << "Failure!" << endl;
        cout << "  " << error.toString() << endl;
    }
    return program;
}

DatalogProgram Parser::parseDatalogProgram(){
    DatalogProgram program;

    match(Token::SCHEMES);
    match(Token::COLON);
    parseScheme();
    parseSchemeList();
    program.setSchemes(schemes);

    match(Token::FACTS);
    match(Token::COLON);
    parseFactList();
    program.setFacts(facts);

    match(Token::RULES);
    match(Token::COLON);
    parseRuleList();
    program.setRules(rules);

    match(Token::QUERIES);
    match(Token::COLON);
    parseQuery();
    parseQueryList();
    program.setQueries(queries);

    match(Token::eof);
    return program;
}

void Parser::parseSchemeList(){
    if (currentToken.getType() == Token::ID) {
        parseScheme();
        parseSchemeList();
    }
}
void Parser::parseFactList(){
    if (currentToken.getType() == Token::ID){
        parseFact();
        parseFactList();
    }
}
void Parser::parseRuleList(){
    if (currentToken.getType() == Token::ID){
        parseRule();
        parseRuleList();
    }
}
void Parser::parseQueryList(){
    if (currentToken.getType() == Token::ID){
        parseQuery();
        parseQueryList();
    }
}

void Parser::parseScheme(){
    match(Token::ID);
    newPredicate.setID(toParse[index-1].getValue());

    match(Token::LEFT_PAREN);
    match(Token::ID);
    newPredicate.addToParameterList(toParse[index-1].getValue());

    parseIdList();
    match(Token::RIGHT_PAREN);
    schemes.push_back(newPredicate);
    newPredicate.clear();
}
void Parser::parseFact(){
    match(Token::ID);
    newPredicate.setID(toParse[index-1].getValue());

    match(Token::LEFT_PAREN);
    match(Token::STRING);
    newPredicate.addToParameterList(toParse[index-1].getValue());

    parseStringList(newPredicate);
    match(Token::RIGHT_PAREN);
    match(Token::PERIOD);
    facts.push_back(newPredicate);
    newPredicate.clear();
}
void Parser::parseRule(){
    newPredicate = parseHeadPredicate();
    newRule = Rule(newPredicate);

    match(Token::COLON_DASH);
    newRule.addToPredicateList(parsePredicate());
    parsePredicateList();

    match(Token::PERIOD);
    rules.push_back(newRule);
}
void Parser::parseQuery(){
    if (currentToken.getType() == Token::ID){
        newPredicate = parsePredicate();
        match(Token::Q_MARK);
        queries.push_back(newPredicate);
        newPredicate.clear();
    }
}

Predicate Parser::parseHeadPredicate(){
    newPredicate = Predicate(currentToken.getValue());
    match(Token::ID);
    match(Token::LEFT_PAREN);
    if (currentToken.getType() == Token::ID){
        newPredicate.addToParameterList(currentToken.getValue());
    }
    match(Token::ID);

    parseIdList();
    match(Token::RIGHT_PAREN);
    return newPredicate;
}
Predicate Parser::parsePredicate(){
    newPredicate = Predicate(currentToken.getValue());
    match(Token::ID);
    match(Token::LEFT_PAREN);
    newPredicate.addToParameterList(parseParameter());
    parseParameterList();
    match(Token::RIGHT_PAREN);
    return newPredicate;
}

void Parser::parsePredicateList(){
    if (currentToken.getType() == Token::COMMA){
        match(Token::COMMA);
        newRule.addToPredicateList(parsePredicate());
        parsePredicateList();
    }
}
void Parser::parseParameterList(){
    if (currentToken.getType() == Token::COMMA){
        match(Token::COMMA);
        newPredicate.addToParameterList(parseParameter());
        parseParameterList();
    }
}
void Parser::parseStringList(Predicate& predicate){
    if (currentToken.getType() == Token::COMMA) {
        match(Token::COMMA);
        match(Token::STRING);
        predicate.addToParameterList(toParse[index-1].getValue());
        parseStringList(predicate);
    }
}
void Parser::parseIdList(){
    if (currentToken.getType() == Token::COMMA) {
        match(Token::COMMA);
        if (currentToken.getType() == Token::ID){
            newPredicate.addToParameterList(currentToken.getValue());
        }
        match(Token::ID);
        parseIdList();
    }
}

Parameter Parser::parseParameter(){
    Parameter newParam;
    if(currentToken.getType() == Token::STRING) {
        newParam.setConstant();
        newParam.setValue(currentToken.getValue());
        match(Token::STRING);
    }
    else if (currentToken.getType() == Token::ID) {
        newParam.setValue(currentToken.getValue());
        match(Token::ID);
    }
    else if (currentToken.getType() == Token::LEFT_PAREN) {
        string value;
        value += parseExpression();
        newParam.setValue(value);
    }
    else {
        throw currentToken;
    }
    return newParam;
}
string Parser::parseExpression(){
    string temporary = "(";
    match(Token::LEFT_PAREN);
    temporary += parseParameter().toString();
    temporary += parseOperator();
    temporary += parseParameter().toString();
    match(Token::RIGHT_PAREN);
    temporary += ")";
    return temporary;
}
string Parser::parseOperator(){
    if (currentToken.getType() == Token::ADD){
        match(Token::ADD);
        return "+";
    }
    else if (currentToken.getType() == Token::MULTIPLY){
        match(Token::MULTIPLY);
        return "*";
    }
    else {
        throw currentToken;
    }
}