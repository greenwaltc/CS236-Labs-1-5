//
// Created by camer on 7/2/2020.
//

#include "Parameter.h"

string Parameter::toString() {
    return value;
}

void Parameter::setValue(string value){
    this->value = value;
}

string Parameter::getValue(){
    return value;
}

bool Parameter::constant(){ return isConstant; }