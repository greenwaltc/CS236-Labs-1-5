//
// Created by camer on 7/31/2020.
//

#ifndef PROJECT1_NODE_H
#define PROJECT1_NODE_H

#include <set>
#include <ctime>
using namespace std;

class Node {
private:

public:
    int ID;
    set<int> adjacency_list;
    bool visited;
    int postorder_number;

    Node() { ID = -1, visited = 0, postorder_number = -1; }
    Node(int set) { ID = set; visited = 0, postorder_number = 0; }
    bool operator <(const Node& other) const {
        return (this->ID < other.ID);
    }
};

#endif //PROJECT1_NODE_H
