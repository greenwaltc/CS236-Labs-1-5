//
// Created by camer on 7/16/2020.
//

#include "Tuple.h"

string Tuple::toString(){
    return "Implement Tuple::printQueries()\n";
}