//
// Created by camer on 7/2/2020.
//

#ifndef PROJECT1_RULE_H
#define PROJECT1_RULE_H

#include <string>
#include <sstream>
#include "Predicate.h"
using namespace std;

class Rule {
private:
    Predicate headPredicate;
    vector<Predicate> predicateList;

public:
    Rule(){}
    Rule(Predicate head);
    string toString();
    void addToPredicateList(Predicate setter);
    Predicate getHead();
    vector<Predicate> getPredicateList();
};

#endif //PROJECT1_RULE_H