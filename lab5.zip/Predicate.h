//
// Created by camer on 7/2/2020.
//

#ifndef PROJECT1_PREDICATE_H
#define PROJECT1_PREDICATE_H

#include <string>
#include <vector>
#include <sstream>
#include "Parameter.h"
#include "Scheme.h"
using namespace std;

class Predicate {
private:
    string ID;
    vector<Parameter> parameterList;
public:
    Predicate(){}
    Predicate(string setter){
        ID = setter;
        parameterList.resize(0);
    }
    string toString();
    void setID(string ID);
    void addToParameterList(Parameter newParam);
    void clear();
    vector<Parameter> getParameterList();
    string getID();
    vector<string> parameterListtoVecString();
};

#endif //PROJECT1_PREDICATE_H