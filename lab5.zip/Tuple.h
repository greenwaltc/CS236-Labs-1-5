//
// Created by camer on 7/16/2020.
//

#ifndef PROJECT1_TUPLE_H
#define PROJECT1_TUPLE_H

#include <vector>
#include <string>
#include <iostream>
using namespace std;

class Tuple : public vector<string>{
private:
    //don't need vector of strings because it is inherited
public:
    Tuple(){}
    string toString();
};

#endif //PROJECT1_TUPLE_H
