//
// Created by camer on 7/16/2020.
//

#include "Scheme.h"

Scheme::Scheme(vector<string> attributeNames){
    for(unsigned int i = 0; i < attributeNames.size(); i++){
        this->push_back(attributeNames[i]);
    }
}

Scheme::Scheme() {}
