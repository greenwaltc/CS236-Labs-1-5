//
// Created by camer on 7/16/2020.
//

#include "Relation.h"

Relation::Relation(string name, Scheme scheme) {
    this->name = name;
    this->scheme = scheme;
}

void Relation::addTuple(Tuple tuple) {
    collection.insert(tuple);
}

string Relation::toString(){
    for (Tuple ob: collection){
        cout << ob.toString();
    }
    return "Finish implementing Relation::printQueries()\n";
}

string Relation::getName(){ return name; }


/*
 * When called, each function will:
 * make an empty relation
 * fill the relation
 * return the relation
 */

Relation Relation::select(int index, string value, string name, Scheme scheme){
    Relation newRelation(name, scheme);
    //Go through each tuple in the current relation
    //check if the value is in the tuple
    //If it is, add that tuple to the new relation
    //Return the new relation
    for (Tuple ob : collection){
        if (ob[index] == value){
            newRelation.addTuple(ob);
        }
    }
    return newRelation;
}

Relation Relation::select(int index1, int index2, string name, Scheme scheme){ //Type 1
    Relation newRelation(name, scheme);
    //Go through each tuple in the current relation
    //Check if the values in at each index are equal
    //If it is, add that tuple to the new relation
    //Return the new relation
    for (Tuple ob : collection){
        if (ob[index1] == ob[index2]){
            newRelation.addTuple(ob);
        }
    }
    return newRelation;
}

Relation Relation::project(vector<int> indexes, string name, vector<string> attributes){ //Type 2
    Relation newRelation(name, Scheme(attributes));

    //Goes through each tuple in the relation and grabs the strings/parameters at the given indexes, adds them to a new tuple, and adds that tuple to the new relation
    for (Tuple ob : collection){
        Tuple newTuple;
        for (unsigned int i = 0; i < indexes.size(); i++){
            newTuple.push_back(ob[indexes[i]]);
        }
        newRelation.addTuple(newTuple);
    }
    return newRelation;
}

Relation Relation::projectRule(string name, vector<string> headVariables) {
    Relation evaluatedRule(name, Scheme(headVariables));

    //This algorithm is less efficient but makes it easier and automatically stores the variables in the right order
    //without keeping track of indexes seperately
    for (Tuple ob : collection){
        Tuple newTuple;
        //Go through each of the variables in the head
        for (unsigned int i = 0; i < headVariables.size(); i++){
            //Go through the joined relation and check which params match the head vars
            for (unsigned int j = 0; j < this->scheme.size(); j++){
                //if they match then add the value in the tuple at j to the new tuple
                if (headVariables[i] == this->scheme[j]){
                    newTuple.push_back(ob[j]);
                }
            }
        }
        evaluatedRule.addTuple(newTuple);
    }
    return evaluatedRule;
}

void Relation::rename(vector<string> names, vector<int> indexes){
    vector<string> variableNames;
    for (unsigned int i = 0; i < indexes.size(); i++){
        variableNames.push_back(names[indexes[i]]);
    }
    this->scheme = Scheme(variableNames);
    this->variableIndexes = indexes;
}
void Relation::rename(vector<string> names){
    this->scheme = Scheme(names);
}

Scheme Relation::getScheme(){ return scheme; }
int Relation::getCollectionSize(){ return collection.size(); }
set<Tuple> Relation::getCollection(){ return collection; }
vector<int> Relation::getVariableIndexes(){ return variableIndexes; }

Relation Relation::join(Relation r1, Relation r2){
    //1. Combine the two schemes
    //2. Go through every pair of tuples
        //a. See if you can combine the tuples
            //Doev every column that is supposed to match actually match?
        //b. If the tuples can be combined, then combine them

    Scheme s = combineSchemes(r1.getScheme(), r2.getScheme());
    Relation r("new", s);

    vector<pair<unsigned int, unsigned int>> indexes = align(r1.getScheme(), r2.getScheme());


    for (Tuple t1 : r1.getCollection()){
        for (Tuple t2 : r2.getCollection()){
            if ( isJoinable(t1, t2, indexes) ){
                Tuple t = joinTuple(t1, t2, indexes);
                r.addTuple(t);
            }
        }
    }
    return r;
}

Scheme Relation::combineSchemes(Scheme s1, Scheme s2){
    Scheme s;
    for (unsigned int i = 0; i < s1.size(); i++){
        s.push_back(s1[i]);
    }
    for (unsigned int i = 0; i < s2.size(); i++){
        if ( (find(s.begin(), s.end(), s2[i]) == s.end()) ){ //If the string wasn't already in the scheme
            s.push_back(s2[i]);
        }
    }
    return s;
}

bool Relation::isJoinable(Tuple t1, Tuple t2, vector<pair<unsigned int, unsigned int>> indexes){
    canJoin = true;
    for (unsigned int i = 0; i < indexes.size(); i++){
        if ( t1.at(indexes[i].first) != t2.at(indexes[i].second) ){
            canJoin = false;
        }
    }
    return canJoin;
}

Tuple Relation::joinTuple(Tuple t1, Tuple t2, vector<pair<unsigned int, unsigned int>> indexes){
    set<unsigned int> do_not_add;
    for (unsigned int i = 0; i < indexes.size(); i++){
        do_not_add.insert(indexes[i].second);
    }
    for (unsigned int i = 0; i < t2.size(); i++){
        if (do_not_add.find(i) == do_not_add.end()){
            t1.push_back(t2[i]);
        }
    }
    return t1;
}

vector<pair<unsigned int, unsigned int>> Relation::align(Scheme s1, Scheme s2){
    pair<unsigned int, unsigned int> temp;
    vector<pair<unsigned int, unsigned int>> indexes;
    for (unsigned int i = 0; i < s1.size(); i++){
        for (unsigned int j = 0; j < s2.size(); j++){
            if (s1[i] == s2[j]){
                temp.first = i;
                temp.second = j;
                indexes.push_back(temp);
            }
        }
    }
    return indexes;
}

void Relation::unionize(Relation ruleRelation){
    stringstream result;
    for (Tuple ob : ruleRelation.collection){
        if (this->collection.insert(ob).second == true){
            result << "  ";
            for (unsigned int i = 0; i < scheme.size(); i++){
                result << scheme[i] << '=' << ob[i];
                if (i < scheme.size() - 1){
                    result << ", ";
                }
            }
            result << '\n';
        }
    }
    cout << result.str();
}