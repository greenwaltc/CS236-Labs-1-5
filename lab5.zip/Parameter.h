//
// Created by camer on 7/2/2020.
//

#ifndef PROJECT1_PARAMETER_H
#define PROJECT1_PARAMETER_H

#include <string>
using namespace std;

class Parameter {
private:
    string value;
    bool isConstant = false;
public:
    Parameter(){
        value = "";
    };
    Parameter(string setString){
        value = setString;
        if (value.at(0) == '\''){
        }
    }
    string toString();
    void setValue(string value);
    string getValue();
    void setConstant(){ isConstant = true; }
    bool constant();
};
#endif //PROJECT1_PARAMETER_H