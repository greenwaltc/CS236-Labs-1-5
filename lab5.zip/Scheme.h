//
// Created by camer on 7/16/2020.
//

#ifndef PROJECT1_SCHEME_H
#define PROJECT1_SCHEME_H

#include <vector>
#include <string>
using namespace std;

class Scheme : public vector<string>{
private:

public:
    Scheme(vector<string> attributeNames);
    Scheme();
};

#endif //PROJECT1_SCHEME_H
