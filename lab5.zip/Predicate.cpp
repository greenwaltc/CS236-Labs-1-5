//
// Created by camer on 7/2/2020.
//

#include "Predicate.h"

string Predicate::toString() {
    stringstream output;
    output << ID << '(';
    for (unsigned int i = 0; i < parameterList.size(); i++){
        output << parameterList[i].toString();
        if (i < parameterList.size()-1){
            output << ",";
        }
    }
    output << ")";
    return output.str();
}

void Predicate::setID(string ID){
    this->ID = ID;
}

void Predicate::addToParameterList(Parameter newParam){
    parameterList.push_back(newParam);
}

void Predicate::clear(){
    parameterList.resize(0);
}

vector<string> Predicate::parameterListtoVecString(){
    vector<string> temp;
    for (unsigned int i = 0; i < this->parameterList.size(); i++){
        temp.push_back(this->parameterList[i].toString());
    }
    return temp;
}

vector<Parameter> Predicate::getParameterList() { return parameterList; }
string Predicate::getID(){ return ID; }