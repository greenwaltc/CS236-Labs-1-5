//
// Created by camer on 7/2/2020.
//

#include "Rule.h"

Rule::Rule(Predicate head){
    headPredicate = head;
}

string Rule::toString(){
    stringstream output;
    output << headPredicate.toString() << " :- ";
    for (unsigned int i = 0; i < predicateList.size(); i++){
        output << predicateList[i].toString();
        if (i < predicateList.size()-1){
            output << ",";
        }
    }
    output << ".";
    return output.str();
}

void Rule::addToPredicateList(Predicate setter){
    predicateList.push_back(setter);
}

Predicate Rule::getHead(){
    return headPredicate;
}
vector<Predicate> Rule::getPredicateList(){
    return predicateList;
}