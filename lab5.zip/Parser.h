//
// Created by camer on 7/2/2020.
//

#ifndef PROJECT1_PARSER_H
#define PROJECT1_PARSER_H

#include "Token.h"
#include "Scanner.h"
#include "DatalogProgram.h"
#include <iostream>

using namespace std;

class Parser{
private:
    vector<Token> toParse;
    int index;
    Token currentToken;
    bool successfulParse;

    vector<Predicate> schemes;
    vector<Predicate> facts;
    vector<Predicate> queries;
    vector<Rule> rules;

    Predicate newPredicate;
    Rule newRule;
public:
    Parser(vector<Token> fromScanner){
        toParse = fromScanner;
        index = 0;
        currentToken = toParse[index];
        successfulParse = false;
    }
    bool success();

    void match(Token::tokenType type);

    DatalogProgram parse();
    DatalogProgram parseDatalogProgram();

    void parseSchemeList();
    void parseFactList();
    void parseRuleList();
    void parseQueryList();

    void parseScheme();
    void parseFact();
    void parseRule();
    void parseQuery();

    Predicate parseHeadPredicate();
    Predicate parsePredicate();

    void parsePredicateList();
    void parseParameterList();
    void parseStringList(Predicate& predicate);
    void parseIdList();

    Parameter parseParameter();
    string parseExpression();
    string parseOperator();
};

#endif //PROJECT1_PARSER_H