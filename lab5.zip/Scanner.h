#pragma once
#include "Token.h"
#include <string>
#include <sstream>
#include <vector>
#include <fstream>

const string SCHEMES = "Schemes", FACTS = "Facts", RULES = "Rules", QUERIES = "Queries";

using namespace std;

class Scanner{
private:
    int currentLine;
    char currChar;
    string value;
    string filename;
    ifstream file;
    vector<Token> allTokens;

public:

    Scanner(string filename){
        currentLine = 1;
        this->filename = filename;
        scanTokens();
    }
    void scanTokens();
    void makeToken(Token::tokenType type, string value, int currentLine);
    void assignKeyWord(string value);
    string toString();
    vector<Token> getAllTokens();
};