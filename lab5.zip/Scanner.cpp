#include "Scanner.h"

using namespace std;

void Scanner::scanTokens(){ /**Read from the input file, store tokens for later use, keep track of the current line number*/
    file.open(filename);
    streampos position;
    int rememberLine = 0;

    while ( !file.eof() ){
        position = file.tellg();
        currChar = file.get();
        rememberLine = currentLine;
        value = ""; //Resets string

        if (isspace(currChar)){ // tab OR newline OR ' '
            if (currChar == '\n'){
                currentLine++;
            }
        }
        else if (isalpha(currChar)) { //Can be IDENT or Keyword
            value += currChar;
            while (isalpha(file.peek()) || isdigit(file.peek())) {
                currChar = file.get();
                value += currChar;
            }
            if (value == "Schemes" || value == "Facts" || value == "Rules" || value == "Queries") { //The ID is a keyword
                assignKeyWord(value);
            } else {
                makeToken(Token::ID, value, currentLine);
            }
        }
        else { //NOT a whitespace or IDENT
            switch (currChar) {
                case EOF:
                    makeToken(Token::eof, "", currentLine);
                    break;
                case ',':
                    makeToken(Token::COMMA, ",", currentLine);
                    break;
                case '.':
                    makeToken(Token::PERIOD, ".", currentLine);
                    break;
                case '?':
                    makeToken(Token::Q_MARK, "?", currentLine);
                    break;
                case '(':
                    makeToken(Token::LEFT_PAREN, "(", currentLine);
                    break;
                case ')':
                    makeToken(Token::RIGHT_PAREN, ")", currentLine);
                    break;

                case ':':
                    if (file.peek() == '-') {
                        makeToken(Token::COLON_DASH, ":-", currentLine);
                        file.get();
                    } else {
                        makeToken(Token::COLON, ":", currentLine);
                    }
                    break;

                case '*':
                    makeToken(Token::MULTIPLY, "*", currentLine);
                    break;

                case '+':
                    makeToken(Token::ADD, "+", currentLine);
                    break;

                case '\'': //The token is a string
                    rememberLine = currentLine;
                    value += currChar;
                    while (!file.eof()) {
                        currChar = file.get();
                        if (currChar == '\n') { //The string hit an end of line
                            currentLine++;
                        }
                        if (currChar == '\'') {
                            if (file.peek() == '\'') { //Case: two single apostrophes contactenated. Add apostrophe
                                value += currChar;
                                currChar = file.get();
                            } else { //The string is terminated
                                value += currChar;
                                makeToken(Token::STRING, value, rememberLine);
                                break;
                            }
                        }
                        if (file.peek() == EOF) { //reached EOF without terminating string
                            value += currChar;
                            makeToken(Token::UNDEFINED, value, rememberLine);
                            makeToken(Token::eof, "", currentLine);
                            break;
                        }
                        //After all checks, concat character to string
                        value += currChar;
                    }
                    break;

                case '#': //The token is a comment
                    rememberLine = currentLine;
                    if (file.peek() == '|'){ //Bar comment, goes multiple lines. If no terminating character, treat like unterminated string
                        value += currChar;
                        while ( !file.eof() ){
                            currChar = file.get();
                            if (currChar == '\n') { //The string hit an end of line
                                currentLine++;
                            }
                            if (currChar == '|' && file.peek() == '#'){ //Reached the end of the block comment
                                value += currChar;
                                currChar = file.get();
                                value += currChar;
                                //makeToken(Token::COMMENT, value, rememberLine);
                                break;
                            }
                            else if (file.peek() == EOF) { //reached EOF without terminating string
                                value += currChar;
                                makeToken(Token::UNDEFINED, value, rememberLine);
                                makeToken(Token::eof, "", currentLine);
                                break;
                            }
                            value += currChar;
                        }
                        break;
                    }
                    else { //It is a line comment and goes to the end of the line
                        value += currChar;
                        while (file.peek() != '\n') {
                            currChar = file.get();
                            value += currChar;
                        }
                        //makeToken(Token::COMMENT, value, currentLine);
                        break;
                    }

                default: //UNDEFINED
                        string temp;
                        temp = currChar;
                        makeToken(Token::UNDEFINED, temp, currentLine);
            }
        }
    }   file.close();
}

void Scanner::assignKeyWord(string value){
    if (value == SCHEMES ) makeToken(Token::SCHEMES, value, currentLine);
    else if (value == FACTS ) makeToken(Token::FACTS, value, currentLine);
    else if (value == RULES ) makeToken(Token::RULES, value, currentLine);
    else if (value == QUERIES ) makeToken(Token::QUERIES, value, currentLine);
}

void Scanner::makeToken(Token::tokenType type, string value, int currentLine){
    Token newToken;
    newToken.setLineNum(currentLine);
    newToken.setValue(value);
    newToken.setType(type);
    this->allTokens.push_back(newToken);
}

vector<Token> Scanner::getAllTokens(){ return allTokens; }

string Scanner::toString(){
    stringstream asString;
    for (unsigned int i = 0; i < allTokens.size(); i++){
        asString << allTokens[i].toString() << '\n';
    }
    asString << "Total Tokens = " << allTokens.size() << '\n';
    return asString.str();
}