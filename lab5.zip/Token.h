#pragma once

#include <string>
#include <sstream>
#include <iostream>
using namespace std;

class Token {
public:
    enum tokenType{
        COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON,
        COLON_DASH, MULTIPLY, ADD, SCHEMES, FACTS, RULES,
        QUERIES, ID, STRING, COMMENT, UNDEFINED, eof
    };
    Token(){
        type = tokenType::UNDEFINED;
        value = "";
        line = 0;
    }
    void setType(tokenType type);
    void setValue(string value);
    void setLineNum(int lineNum);
    string toString();

    tokenType getType();
    string getValue();
    int getLine();

private:
    tokenType type;
    string value;
    int line;
};