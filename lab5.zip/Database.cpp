//
// Created by camer on 7/16/2020.
//

#include "Database.h"

void Database::addTuple(string name, Tuple addTuple){
    cout << "Implement addTuple" << '\n';
}